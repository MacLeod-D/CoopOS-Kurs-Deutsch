
// Diese Pins sind nur für den Logic Analyzer und könne für andere Aufgaben benutzt werden!

#define TASK_3_4_PIN  3           // D3   für LA Darstellung Task3, Task4

#define Task2_Pin     5           // D5   Output Pin genutzt von Task2

#define GPIO_ISR_PIN  6           // D6   IRQ Test Pin

#define LA_PIN        4           // D4   Logic Analyzer Pin Scheduler

#define EXT_IRQ_PIN   2           // D2   External Interrupt


//+ Serial Out TX
